import { defineConfig } from 'tsup';
import fs from 'fs';
import path from 'path';

export default defineConfig({
    entry: ['src/extensions/initPremium.ts'],
    format: ['esm'],
    sourcemap: true,
    bundle: true,
    splitting: false,
    esbuildOptions(options) {
        options.jsx = 'transform';
        options.jsxFactory = 'React.createElement';
        options.jsxFragment = 'React.Fragment';
    },
    external: [
        'react', 'react-dom', 'react-router-dom',
        'react-i18next', 'i18next', '@supabase/supabase-js',
        'sonner', 'lucide-react', 'recharts', 'date-fns',
        'otpauth', 'qrcode', 'jsqr', 'zod',
        'react-hook-form', '@hookform/resolvers',
        '@tanstack/react-query', 'react-helmet-async',
        /^@radix-ui\//,
    ],
    esbuildPlugins: [
        {
            name: 'premium-resolve',
            setup(build) {
                // Handle @/ imports
                build.onResolve({ filter: /^@\// }, (args) => {
                    const relPath = args.path.replace(/^@\//, './src/');
                    const exts = ['.ts', '.tsx', '.js', '.jsx', '/index.ts', '/index.tsx'];
                    for (const ext of exts) {
                        if (fs.existsSync(relPath + ext)) {
                            return { path: path.resolve(relPath + ext) };
                        }
                    }
                    return { path: args.path, external: true };
                });

                // Handle relative imports to non-existent files (Core dependencies)
                build.onResolve({ filter: /^\.\.?\// }, (args) => {
                    if (!args.importer) return null;
                    const dir = path.dirname(args.importer);
                    const resolved = path.resolve(dir, args.path);
                    const exts = ['.ts', '.tsx', '.js', '.jsx', '/index.ts', '/index.tsx', ''];
                    const exists = exts.some(ext => fs.existsSync(resolved + ext));
                    if (!exists) {
                        // Convert to @/ path for Core resolution
                        const fromSrc = path.relative(path.resolve('./src'), resolved).replace(/\\/g, '/');
                        return { path: `@/${fromSrc}`, external: true };
                    }
                    return null;
                });
            },
        },
    ],
});
